//
//  ViewController.m
//  PrivateSpecTest
//
//  Created by ydd on 2021/1/6.
//

#import "ViewController.h"
#import <NSBundle+YDD.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSBundle *bundle = [NSBundle ydd_bundleWithPod:@"YDDPPStickerKeyboard" bundleName:@"YDDPPStickerKeyboard"];
    NSString *path = [bundle pathForResource:@"delete-emoji" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];

    if (image) {
        NSLog(@"image size : %@", NSStringFromCGSize(image.size));
    }
    
}


@end
