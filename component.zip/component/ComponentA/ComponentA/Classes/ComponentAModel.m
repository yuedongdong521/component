//
//  ComponentAModel.m
//  ComponentA
//
//  Created by ydd on 2021/1/5.
//

#import "ComponentAModel.h"

@implementation ComponentAModel

+ (void)testMoth
{
    NSLog(@"%@ - %s", NSStringFromClass([ComponentAModel class]), __func__);
}


@end
