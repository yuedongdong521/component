# ComponentA

[![CI Status](https://img.shields.io/travis/yuedongdong521/ComponentA.svg?style=flat)](https://travis-ci.org/yuedongdong521/ComponentA)
[![Version](https://img.shields.io/cocoapods/v/ComponentA.svg?style=flat)](https://cocoapods.org/pods/ComponentA)
[![License](https://img.shields.io/cocoapods/l/ComponentA.svg?style=flat)](https://cocoapods.org/pods/ComponentA)
[![Platform](https://img.shields.io/cocoapods/p/ComponentA.svg?style=flat)](https://cocoapods.org/pods/ComponentA)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

ComponentA is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'ComponentA'
```

## Author

yuedongdong521, 1067221279@qq.com

## License

ComponentA is available under the MIT license. See the LICENSE file for more info.
