//
//  YDDAppDelegate.h
//  ComponentA
//
//  Created by yuedongdong521 on 01/05/2021.
//  Copyright (c) 2021 yuedongdong521. All rights reserved.
//

@import UIKit;

@interface YDDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
