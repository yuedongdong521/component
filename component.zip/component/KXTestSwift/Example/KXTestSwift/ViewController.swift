//
//  ViewController.swift
//  KXTestSwift
//
//  Created by yuedongdong521 on 06/23/2021.
//  Copyright (c) 2021 yuedongdong521. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

