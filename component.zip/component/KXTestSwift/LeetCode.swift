//
//  LeetCode.swift
//  KXTestSwift
//
//  Created by ydd on 2021/6/23.
//

import Foundation

func leetCode() {
    
}

func isValidSudoku(_ board: [[Character]]) -> Bool {

    var set = Set<Character>()
    var sudo = true
    board.forEach { (arr) in
        arr.forEach { (a) in
            if set.contains(a) {
                sudo = false
                return
            }
            set.insert(a)
        }
        if !sudo {
            return
        }
    }
    
    return sudo
}
