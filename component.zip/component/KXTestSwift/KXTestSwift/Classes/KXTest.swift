//
//  KXTest.swift
//  KXTestSwift
//
//  Created by ydd on 2021/6/23.
//

import Foundation

public extension String {
    
    func subString(toIndex index: Int) -> String {
        if self.count <= index {
            return self
        }
        let endIndex = self.index(self.startIndex, offsetBy: index)
       return String(self[self.startIndex..<endIndex])
    }
    
    func subString(formIndex index: Int) -> String {
        if self.count <= index {
            return ""
        }
        let startIndex = self.index(self.startIndex, offsetBy: index)
        return String(self[startIndex..<self.endIndex])
    }
    
    func replace(of a: String, with b: String) -> String {
        return self.replacingOccurrences(of: a, with: b,
                                         options: String.CompareOptions.caseInsensitive,
                                         range: Range(uncheckedBounds: (self.startIndex, self.endIndex)))
    }
    
}
