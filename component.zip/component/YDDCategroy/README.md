# YDDCategroy

[![CI Status](https://img.shields.io/travis/yuedongdong521/YDDCategroy.svg?style=flat)](https://travis-ci.org/yuedongdong521/YDDCategroy)
[![Version](https://img.shields.io/cocoapods/v/YDDCategroy.svg?style=flat)](https://cocoapods.org/pods/YDDCategroy)
[![License](https://img.shields.io/cocoapods/l/YDDCategroy.svg?style=flat)](https://cocoapods.org/pods/YDDCategroy)
[![Platform](https://img.shields.io/cocoapods/p/YDDCategroy.svg?style=flat)](https://cocoapods.org/pods/YDDCategroy)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

YDDCategroy is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'YDDCategroy'
```

## Author

yuedongdong521, 1067221279@qq.com

## License

YDDCategroy is available under the MIT license. See the LICENSE file for more info.
