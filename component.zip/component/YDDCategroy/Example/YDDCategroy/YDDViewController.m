//
//  YDDViewController.m
//  YDDCategroy
//
//  Created by yuedongdong521 on 01/05/2021.
//  Copyright (c) 2021 yuedongdong521. All rights reserved.
//

#import "YDDViewController.h"

@interface YDDViewController ()

@end

@implementation YDDViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
