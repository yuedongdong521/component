# YDDPPStickerKeyboard

[![CI Status](https://img.shields.io/travis/yuedongdong521/YDDPPStickerKeyboard.svg?style=flat)](https://travis-ci.org/yuedongdong521/YDDPPStickerKeyboard)
[![Version](https://img.shields.io/cocoapods/v/YDDPPStickerKeyboard.svg?style=flat)](https://cocoapods.org/pods/YDDPPStickerKeyboard)
[![License](https://img.shields.io/cocoapods/l/YDDPPStickerKeyboard.svg?style=flat)](https://cocoapods.org/pods/YDDPPStickerKeyboard)
[![Platform](https://img.shields.io/cocoapods/p/YDDPPStickerKeyboard.svg?style=flat)](https://cocoapods.org/pods/YDDPPStickerKeyboard)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

YDDPPStickerKeyboard is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'YDDPPStickerKeyboard'
```

## Author

yuedongdong521, 1067221279@qq.com

## License

YDDPPStickerKeyboard is available under the MIT license. See the LICENSE file for more info.
