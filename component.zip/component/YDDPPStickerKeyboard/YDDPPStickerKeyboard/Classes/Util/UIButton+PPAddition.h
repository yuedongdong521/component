//
//  PPButton.h
//  PPStickerKeyboard
//
//  Created by Vernon on 2018/1/19.
//  Copyright © 2018年 Vernon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PPButton : UIButton

@property (nonatomic) UIEdgeInsets touchInsets;

@end
