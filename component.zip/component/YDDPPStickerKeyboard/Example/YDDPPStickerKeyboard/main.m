//
//  main.m
//  YDDPPStickerKeyboard
//
//  Created by yuedongdong521 on 01/07/2021.
//  Copyright (c) 2021 yuedongdong521. All rights reserved.
//

@import UIKit;
#import "YDDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YDDAppDelegate class]));
    }
}
