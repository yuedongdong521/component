//
//  ViewController.m
//  MaineComponent
//
//  Created by ydd on 2021/1/5.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    

    
}


@end
