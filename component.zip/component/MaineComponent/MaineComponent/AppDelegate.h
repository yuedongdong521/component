//
//  AppDelegate.h
//  MaineComponent
//
//  Created by ydd on 2021/1/5.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

