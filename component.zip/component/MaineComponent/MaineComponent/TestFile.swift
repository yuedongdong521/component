//
//  TestFile.swift
//  MaineComponent
//
//  Created by ydd on 2021/6/23.
//

import Foundation
import KXTestSwift

@objcMembers class TestFunc: NSObject {
    
    static func testAction() {
        let str = "swift"
        
        print("swift : \(str.subString(toIndex: 2))")
        print("swift : \(str.subString(formIndex: 2))")
        
        let chenguo = "woAchenaguo"
        let c1 = chenguo.replace(of: "a", with: "A")
        let c2 = c1.replace(of: "1", with: "2")
        print("swift c1 = \(c1), c2 = \(c2)")
        
        let sumuchen = "woacaosumucheng"
        
        let su = sumuchen.replace(of: "o", with: "O")
        print("swift : \(su)")
        
        testEach()
        
        TestFunc().testObj()
        
        TestFunc().foo()
        
        TestFunc().test()
    }
    
    
    static func testEach() {
        let arr = [1, 2, 3, 4, 5]
        arr.forEach { (a) in
            print("each : \(a)")
            if a == 3 {
                return
            }
        }
        print("xxxxxxxxx")
    }
    
    func testObj() {
        
        defer {
            print("defer")
        }
        let arr = [1, 2, 3, 4, 5]
        for a in arr {
            print("for : \(a)")
            if a == 3 {
                break
            }
        }
        print("sssssssss")
        
    }
    
    func foo() {
        print("1")
        defer {
            print("6")
        }
        print("2")
        defer {
            print("5")
        }
        print("3")
        defer {
            print("4")
        }
        print("wwwwwwwwwww")
        
    }
    
    func test() {
        testDefer()
        testT()
        
    }
    
    
    func testDefer() {
        do {
            throw NSError(domain: "defer error", code: -12, userInfo: ["error" : "123"])
        } catch {
            print(error)
        }
    }
    
    enum TestStatus: Error {
        case success
        case faile(_ code: Int)
    }
    
    func testThrow(_ a: Int) throws -> Int {
        if a > 100 {
            return a
        } else if (a > 10) {
            throw TestStatus.success
        } else {
            throw TestStatus.faile(a)
        }
    }
    
    func testT() {
        var index = 0;
        defer {
            print("index : \(index)")
        }
        
        do {
            index += 1;
            let a = try testThrow(101)
            let b = try testThrow(-1)
            let c = try testThrow(11)
            print("testT: a = \(a), b = \(b), c = \(c)")
        } catch TestStatus.faile(let code) {
            index += 1;
            print("code = \(code)")
        } catch TestStatus.success {
            index += 1;
            print("success")
        } catch {
            index += 1;
            print(error)
        }
    }
    
    func testC() {
        
        
    }
    
    
    
}


